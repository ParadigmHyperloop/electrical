# Main Power Board
This board provides approriate conversion of power from 120/240VAC and 37V nominal battery packs and distribution to both 24V and 5V system loads (all loads).